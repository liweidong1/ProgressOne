//
//  main.m
//  下载进度
//
//  Created by liweidong on 17/7/21.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
