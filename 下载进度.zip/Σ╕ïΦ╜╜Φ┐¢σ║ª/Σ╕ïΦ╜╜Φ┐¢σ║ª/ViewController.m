//
//  ViewController.m
//  下载进度
//
//  Created by liweidong on 17/7/21.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "LoopProgressView.h"
#import "IWLoadingProgressView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //进度条1
//    [self addOneProgress];
    //进度条2
    [self addLoadProgress];

}
- (void)addLoadProgress
{
    IWLoadingProgressView *loadProgress = [IWLoadingProgressView progressView];
    loadProgress.frame = CGRectMake(0, 0, 100,100);
    loadProgress.progress = 1.0;
    loadProgress.center = self.view.center;
    [self.view addSubview:loadProgress];
}

-(void)addOneProgress
{
    LoopProgressView *custom = [[LoopProgressView alloc]initWithFrame:CGRectMake(50, 100, 100, 100)];
    custom.progress = 1;
    [self.view addSubview:custom];
}

@end
