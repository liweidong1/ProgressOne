//
//  IWLoadingProgressView.h
//  下载进度
//
//  Created by liweidong on 17/7/21.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IWLoadingProgressView : UIView
@property (nonatomic,assign) CGFloat progress;
//清除指示器
- (void)dismiss;
//示例化对象
+ (id)progressView;
@end
